package dao;

import com.RunBoot;
import com.entity.COrder;
import com.repository.COrderRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Random;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RunBoot.class)
public class TestMasterSlave1 {

  @Resource private COrderRepository cOrderRepository;

  @Test
  public void testAdd() {
    for (int i = 0; i < 10; i++) {
      final COrder order = new COrder();
      order.setCompanyId(i);
      order.setUserId(new Random().nextInt(100));
      order.setCreateTime(new Date());
      order.setUpdateTime(new Date());
      order.setDel(false);
      order.setPositionId(i);
      order.setPublishUserId(i);
      order.setStatus("a"+i);
      order.setResumeType(i);
      cOrderRepository.save(order);
    }
  }

  @Test
  public void testFind() {
    final List<COrder> list = cOrderRepository.findAll();
    list.forEach(
        order -> {
          System.out.println(order.getId());
        });
  }
}
